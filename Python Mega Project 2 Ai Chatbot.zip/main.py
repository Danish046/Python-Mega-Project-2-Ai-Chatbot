import os
import re
import requests
from dotenv import load_dotenv
load_dotenv()

WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
NEWS_API_KEY = os.getenv("NEWS_API_KEY")

def get_weather(city):
    if not WEATHER_API_KEY:
        return "Weather API key missing."
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city},PK&appid={WEATHER_API_KEY}&units=metric"
    print("DEBUG: Final URL =", url) 
    
    try:
        r = requests.get(url, timeout=8).json()
        print("DEBUG: API Response =", r)
    except Exception as e:
        return f"API error: {e}"

    if r.get("cod") == 200:
        temp = r["main"]["temp"]
        desc = r["weather"][0]["description"]
        return f"{city.title()}: {temp}°C, {desc}"
    else:
        return f"City '{city}' not found!"

def get_news(topic=None):
    if not NEWS_API_KEY:
        return "News API key missing!"

    if topic:
        url = f"https://newsapi.org/v2/everything?q={topic}&pageSize=5&apiKey={NEWS_API_KEY}"
    else:
        url = f"https://newsapi.org/v2/top-headlines?country=us&pageSize=5&apiKey={NEWS_API_KEY}"

    try:
        r = requests.get(url, timeout=8).json()
    except Exception as e:
        return f"API error: {e}"

    if r.get("status") == "ok":
        articles = r.get("articles", [])
        if not articles:
            return "No news found."
        titles = [f"{i+1}. {a['title']}" for i, a in enumerate(articles[:5])]
        return "\n".join(titles)

    return "News API error!"

def get_joke():
    try:
        r = requests.get("https://official-joke-api.appspot.com/jokes/random", timeout=6)
        if r.status_code == 200:
            j = r.json()
            return f"{j['setup']} -- {j['punchline']}"
    except:
        pass
    return "No jokes available right now."

def extract_city(text):
    m = re.search(r"weather in ([a-zA-Z\s]+)", text)
    return m.group(1).strip() if m else ""

def chatbot():
    print("Chatbot: Hi! Ask me about weather, news, or jokes. Type 'bye' to exit.")
    while True:
        user_input = input("You: ").lower().strip()

        if user_input in ("bye", "exit", "quit"):
            print("Chatbot: Goodbye!")
            break

        elif "weather" in user_input:
            city = extract_city(user_input)
            if city:
                print("Chatbot:", get_weather(city))
            else:
                print("Chatbot: Please say 'weather in <city>'.")

        elif "news" in user_input:
            topic = None
            if "about" in user_input:
                topic = user_input.split("about")[-1].strip()
            print("Chatbot:", get_news(topic))

        elif "joke" in user_input or "jokes" in user_input:
            print("Chatbot:", get_joke())

        else:
            print("Chatbot: Sorry, I only know weather, news, and jokes.")

if __name__ == "__main__":
    if not WEATHER_API_KEY:
        print("Weather API key missing! Add it to your .env file.")
    if not NEWS_API_KEY:
        print("News API key missing! Add it to your .env file.")

    chatbot()
